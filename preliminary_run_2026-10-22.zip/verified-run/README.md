# Verifizierter Lean-Stand

Abschluss: 22.10.2026, 12:49:39 MESZ (10:49:39 UTC).
1.505/1.505 eigene Module; Lake-Build erfolgreich (5.582 Jobs).
Anschliessend: `Verification/Final.lean` separat erfolgreich geprueft.
Fortgesetzter lokaler Lauf mit wiederverwendetem Cache, kein Neubau ab null.
`build.log` ist der unveraenderte Abschlusslog.

Bewiesene Aussage: `DivisorProof.Watt41 -> Sechstmoment.FullGoal`.
`Watt41` bleibt Voraussetzung. Axiome: `propext`, `Classical.choice`, `Quot.sound`.
Die Abschlusspruefung kontrolliert auch Zielaussage und numerische Schranke.

## Wiederholen

Linux/WSL, Git und Lean ueber elan erforderlich; Abhaengigkeiten werden
heruntergeladen. Lean 4.34.0 und alle neun Git-Abhaengigkeiten sind durch
`lean-toolchain`, `lakefile.lean` und `lake-manifest.json` festgelegt.
Im entpackten Ordner ausfuehren:

```sh
sha256sum --strict -c SHA256SUMS
lake build
lake env lean Sechstmoment/Verification/Final.lean
```

Jeder Befehl muss mit Exitcode 0 enden. Auf frischem Source ohne Projektcache
wird neu gebaut; das kann lange dauern. Builddateien und Toolchain sind
nicht enthalten. `verification.log` dokumentiert die erneute Paketpruefung
mit dem vorhandenen, zum Quellstand passenden Cache.

## Herkunft

Exakte Quellen aus Checkpoint `2026-10-22-125301-completed`,
Namespace `Sechstmoment`. Das spaeter umbenannte Repository heisst `SixthMoment`.
SHA-256 des urspruenglichen Checkpoint-Archivs:
`5184304c4b6df24e9e21a4ec3a3bff7b4aed750722ee626dba8372db9fefa0e8`

`SHA256SUMS` erfasst alle Paketdateien ausser sich selbst. Pruefsummen sichern
die Dateiintegritaet; unabhaengige inhaltliche Verifikation erfolgt durch Lean.
Salt-Lizenz und Herkunft stehen in `Salt/LICENSE` und `Salt/UPSTREAM.json`.
